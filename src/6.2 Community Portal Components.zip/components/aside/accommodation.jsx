import React from 'react';


const Accommodation = () => {
 
  return (
	<div className="accommodation">
		<h3>Accommodation</h3>
	</div>
  );
};

export default Accommodation;