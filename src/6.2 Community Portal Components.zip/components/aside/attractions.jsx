import React from 'react'

const Attractions = () => {
 
  return (
	<div className="attractions">
		<h3>Attractions</h3>
	</div>
  );
};

export default Attractions;