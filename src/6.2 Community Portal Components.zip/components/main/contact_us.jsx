import React from 'react';

const Contact = () => {
    return (
		<div className="contact_us">
			<h3>Photo Gallery</h3>
		</div>
    );
};

export default Contact;