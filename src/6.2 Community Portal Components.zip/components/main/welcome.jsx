import React from 'react'

const Welcome = () => {
 
  return (
	<div className="welcome">
		<h2>Welcome</h2>
	</div>
  );
};

export default Welcome;