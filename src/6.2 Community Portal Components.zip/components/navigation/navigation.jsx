import React from "react";


const Navigation = () => {

    return (
		<h3>Navigation</h3>
    );
};

export default Navigation;
