import React from 'react'

const Header = () => {
  return (
	<div className="header">
		<h1>Community Portal</h1>
	</div>
  );
}

export default Header
