import React from 'react';

const CommunityBlog = () => {
 
  return (
	<div className="community_blog">
		<h3>Community Blog</h3>
	</div>
  );
};

export default CommunityBlog;