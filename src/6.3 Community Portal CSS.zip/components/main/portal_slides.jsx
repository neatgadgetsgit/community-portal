import React from "react";

const PortalSlides = () => {
 
  return (
	<div className="portal_slides">
		<h3>Photo Gallery</h3>
	</div>
  );
};

export default PortalSlides;
