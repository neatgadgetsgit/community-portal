import React from 'react';

const Weather = () => {
  return (
		<h3>Weather Dashboard</h3>
  );
}

export default Weather;