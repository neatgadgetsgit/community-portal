import React from 'react'

const Events = () => {
 
  return (
	<div className="events">
		<h3>Events</h3>
	</div>
  );
};

export default Events;