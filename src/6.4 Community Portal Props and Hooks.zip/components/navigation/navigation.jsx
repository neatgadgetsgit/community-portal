import React from "react";


const Navigation = () => {

    return (
	<div className="navigation">
		<h3>Navigation</h3>
	</div>
    );
};

export default Navigation;
